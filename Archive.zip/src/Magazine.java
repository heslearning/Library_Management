public class Magazine extends LibraryItem {
    public Magazine(String title, int issueNumber) {
        super(title);
        // Implement your own logic here then remove the comment.
    }

    public int getIssueNumber() {
        return 0; // Dummy return value. Implement your own logic here then remove the comment.
    }

    public void setIssueNumber(int issueNumber) {
        // Implement your own logic here then remove the comment.
    }

    @Override
    public double getDailyLateFee() {
        return 0; // Dummy return value. Implement your own logic here then remove the comment.
    }

    @Override
    public int getBaseLoanPeriod() {
        return 0; // Dummy return value. Implement your own logic here then remove the comment.
    }

    @Override
    public double getMaximumFine() {
        return 0; // Dummy return value. Implement your own logic here then remove the comment.
    }

    @Override
    public String toString() {
        return getTitle() + " (Magazine, Issue " + getIssueNumber() + ")";
    }
}
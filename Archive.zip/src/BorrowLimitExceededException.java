public class BorrowLimitExceededException extends UnsupportedOperationException {
    public BorrowLimitExceededException(String message) {
        super(message);
    }
}
public class ItemNotLoanableException extends UnsupportedOperationException {
    public ItemNotLoanableException(String message) {
        super(message);
    }
}
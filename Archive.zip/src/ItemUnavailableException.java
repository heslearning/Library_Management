public class ItemUnavailableException extends UnsupportedOperationException {
    public ItemUnavailableException(String message) {
        super(message);
    }
}
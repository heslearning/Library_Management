public class Book extends LibraryItem {

    public Book(String title, String isbn) {
        super(title);
    }

    public String getISBN() {
        return ""; // Dummy return value. Implement your own logic here then remove the comment.
    }

    public void setISBN(String isbn) {
        // Implement your own logic here then remove the comment.
    }

    @Override
    public double getDailyLateFee() {
        return 0; // Dummy return value. Implement your own logic here then remove the comment.
    }

    @Override
    public int getBaseLoanPeriod() {
        return 0; // Dummy return value. Implement your own logic here then remove the comment.
    }

    @Override
    public double getMaximumFine() {
        return 0; // Dummy return value. Implement your own logic here then remove the comment.
    }

    @Override
    public String toString() {
        return getTitle() + " (Book, ISBN: " + getISBN() + ")";
    }
}
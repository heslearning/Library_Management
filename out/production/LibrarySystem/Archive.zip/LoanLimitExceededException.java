public class LoanLimitExceededException extends UnsupportedOperationException {
    public LoanLimitExceededException(String message) {
        super(message);
    }
}

public class AccountSuspendedException extends UnsupportedOperationException {
    public AccountSuspendedException (String message) {
        super(message);
    }
}
public class DVD extends LibraryItem {
    public DVD(String title, int runtimeMinutes) {
        super(title);
        // Implement your own additional logic here then remove the comment.
    }

    public int getRuntimeLength() {
        return 0; // Dummy return value. Implement your own logic here then remove the comment.
    }

    public void setRuntimeLength(int runtimeMinutes) {
        // Implement your own logic here then remove the comment.
    }

    @Override
    public double getDailyLateFee() {
        return 0; // Dummy return value. Implement your own logic here then remove the comment.
    }

    @Override
    public int getBaseLoanPeriod() {
        return 0; // Dummy return value. Implement your own logic here then remove the comment.
    }

    @Override
    public double getMaximumFine() {
        return 0; // Dummy return value. Implement your own logic here then remove the comment.
    }

    @Override
    public String toString() {
        return getTitle() + " (DVD, Runtime Length: " + getRuntimeLength()  + " Minutes)";
    }
}